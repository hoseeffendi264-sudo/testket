import "server-only";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "./generated/prisma/client";

const g = globalThis as unknown as { prisma?: PrismaClient };

function buat() {
  const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL });
  return new PrismaClient({ adapter });
}

export const prisma = g.prisma ?? buat();

if (process.env.NODE_ENV !== "production") {
  g.prisma = prisma;
}
